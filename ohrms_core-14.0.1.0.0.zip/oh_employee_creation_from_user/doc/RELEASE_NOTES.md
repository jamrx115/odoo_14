## Module <hr_employee_creation_from_user>

#### 06.10.2020
#### Version 14.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
